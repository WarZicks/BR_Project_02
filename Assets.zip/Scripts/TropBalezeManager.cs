﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TropBalezeManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		MaFonctionAvecParametre ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void FixedUpdate () {
		
	}

	void MaFonctionAvecParametre ()
	{
		Debug.Log(1032 * 2);
	}
}
